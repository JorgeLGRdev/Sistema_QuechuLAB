<div>
    {{-- Close your eyes. Count to one. That is how long forever feels. --}}
    <label>Doctor:</label>
    <input type="text" wire:model.live="doctor" placeholder="A quien corresponda" class="form-control rounded-md shadow-sm border-gray-300">
    {{-- $doctor --}}
</div>
