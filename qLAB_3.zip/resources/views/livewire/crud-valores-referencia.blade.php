<div class="container mx-auto px-4">

    <div class="overflow-y-auto">
        <div class="grid grid-cols-2 gap-4">
            <div>
                @livewire('detalleEstudio')
            </div>
        
            <div>
                @livewire('formulario-v-r')
            </div>
        </div>
            
        <div>
            @livewire('tabla-v-r')
        </div>
        <br>
    </div>

</div>
