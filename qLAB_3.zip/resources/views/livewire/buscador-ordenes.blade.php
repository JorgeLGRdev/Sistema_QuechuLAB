<div>
    {{-- Nothing in the world is as soft and yielding as water. --}}
    <input type="text" wire:model.live="busquedaOrden" placeholder="Buscar orden por clave..." class="form-control rounded-md shadow-sm border-gray-300" autofocus>
    <hr>
    <div wire:loading>Buscando...</div>
</div>
