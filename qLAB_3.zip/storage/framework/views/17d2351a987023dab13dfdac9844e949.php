
<div>

    <div class="grid grid-cols-2 gap-4">
        <div>
            <input id="study" type="text" wire:model.live="study" placeholder="Buscar estudios..." class="form-control rounded-md shadow-sm border-gray-300">
        </div>
       
        <div>
        </div>
    </div>

    <hr>
        <!--[if BLOCK]><![endif]--><?php if($study): ?>
            <!--[if BLOCK]><![endif]--><?php if($studies->isNotEmpty()): ?>
                <ul>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $studies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $study): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li wire:click="select(<?php echo e($study->id); ?>)" class="hover:bg-teal-200 text-blue">
                            <?php echo e($study->nombre); ?> - <?php echo e($study->precio); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                </ul>
            <?php else: ?>
                <p>No se encontraron resultados</p>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

    <table class="w-full text-sm text-left text-gray-500">
        <thead class="bg-teal-500 text-white">
            <tr class="hover:bg-teal-700">
                <th class="px-4 py-2">Estudio</th>
                <th class="px-4 py-2">Precio</th>
                <th class="px-4 py-2">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selected; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $study): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-white hover:bg-teal-100">
                    <td class="border px-4 py-2"><?php echo e($study->nombre); ?></td>
                    <td class="border px-4 py-2"><?php echo e($study->precio); ?></td>
                    <td class="border px-4 py-2">
                        <button wire:click="quitarEstudio(<?php echo e($index); ?>)" class="text-red-500 hover:text-red-700">Quitar</button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>
    
    <div class="flex items-center border-b border-teal-500 py-2">
        <span>TOTAL:</span>
        <input class="appearance-none bg-transparent border-none w-full text-gray-700 mr-3 py-1 px-2 leading-tight focus:outline-none" type="text" placeholder="Total" aria-label="Total" readonly wire:model="total">
 
    </div>
    

</div><?php /**PATH C:\xampp\htdocs\Sistema_QuechuLAB\resources\views/livewire/estudios.blade.php ENDPATH**/ ?>