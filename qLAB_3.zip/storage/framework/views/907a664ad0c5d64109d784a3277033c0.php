<div>
    <!--[if BLOCK]><![endif]--><?php if($estudios): ?>
    <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        <h2 class="text-2xl font-semibold text-blue-600 text-center">Validación de resultados</h2>
        <div class="overflow-y-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Clave
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Estudio
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Resultado
                        </th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Unidades
                        </th>
                        <th scope="col" colspan="3" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Valores de referencia
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $estudios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indice => $estudio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--[if BLOCK]><![endif]--><?php if($estudio->reporte_especial === 'S'): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php echo e($estudio->id); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php echo e($estudio->nombre); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap"></td>
                            <td class="px-6 py-4 whitespace-nowrap"></td>
                            <td class="px-6 py-4 whitespace-nowrap"></td>
                        </tr>
                            <?php
                                $resultadosAux = \App\Helpers\Helpers::obtenerResultados($estudio->id, $orden->id);               
                            ?>   
                            <!--[if BLOCK]><![endif]--><?php if(!$resultadosAux->isEmpty()): ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $resultadosAux; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap"></td>
                                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($resultado->parametro); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <!--[if BLOCK]><![endif]--><?php if($resultado->val_ref_texto != '' || $resultado->val_ref_inicial != '' || $resultado->val_ref_final != ''): ?>
                                            <input type="text" value="<?php echo e($resultado->resultado); ?>" class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md" readonly>
                                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($resultado->unidades); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($resultado->val_ref_texto); ?></td>
                                                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($resultado->val_ref_inicial); ?></td>
                                                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($resultado->val_ref_final); ?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->   
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                        <?php else: ?>
                            <!--[if BLOCK]><![endif]--><?php if($estudio->es_perfil === 's'): ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php echo e($estudio->id); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php echo e($estudio->nombre); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap"></td>
                                <td class="px-6 py-4 whitespace-nowrap"></td>
                                <td class="px-6 py-4 whitespace-nowrap"></td>
                            </tr>
                            <?php else: ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php echo e($estudio->id); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php echo e($estudio->nombre); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <input type="text" wire:model="resultados.<?php echo e($estudio->id); ?>"  class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md" readonly>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php echo e($estudio->unidades); ?>

                                </td>
                                
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <table class="min-w-full divide-y divide-gray-200">
                                        <tbody  class="bg-white divide-y divide-gray-200">
                                            <?php
                                            $valoresReferenciaDelEstudio = $valores_referencia[$indice];
                                            ?>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $valoresReferenciaDelEstudio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valorReferencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <!-- Aquí puedes trabajar con cada valor de referencia del estudio actual -->
                                            <tr>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm"><?php echo e($valorReferencia->valor_texto); ?></td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm"><?php echo e($valorReferencia->valor_inicial); ?></td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm"><?php echo e($valorReferencia->valor_final); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->                         
                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]--> 
                </tbody>
            </table>

            <div class="flex justify-center mt-4">
                <button wire:click="guardarValidacion" class="px-4 py-2 bg-teal-600 text-white rounded hover:bg-teal-700">Validar Resultados</button>
                <button wire:click="resetData" class="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700">Cancelar</button>
            </div>          
            <div wire:loading>Cargando...</div>    
        </div>
    </div>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\Sistema_QuechuLAB\resources\views/livewire/validacion-resultados.blade.php ENDPATH**/ ?>