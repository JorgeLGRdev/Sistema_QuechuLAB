<div>
    
    <!--[if BLOCK]><![endif]--><?php if($ordenSeleccionada): ?>
    <div class="grid grid-cols-2 gap-4">
        <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
            <h2 class="font-bold text-xl mb-2">Detalle de la orden:</h2>
            <p class="mb-2"><span class="font-semibold">Clave:</span> <?php echo e($ordenSeleccionada->id); ?> <span class="font-semibold">Total:</span> $<?php echo e($ordenSeleccionada->total); ?></p>
            <p class="mb-2"><span class="font-semibold">Paciente:</span> <?php echo e($paciente->nombre); ?> <?php echo e($paciente->apellido_paterno); ?> <?php echo e($paciente->apellido_materno); ?> 
                <span class="font-semibold">    Sexo:</span> <?php echo e(($paciente->sexo === 'F' ? 'Femenino': 'Masculino')); ?>

                <span class="font-semibold">    Edad:</span> <?php echo e(\App\Helpers\Helpers::obtenerEdad($paciente->fecha_nacimiento)); ?>

            </p>

            <p class="mb-2"><span class="font-semibold">Estudios:</span> <?php echo e(\App\Helpers\Helpers::estudiosOrden($ordenSeleccionada->id)); ?></p>
            <p class="mb-2"><span class="font-semibold">Doctor:</span> <?php echo e($ordenSeleccionada->doctor); ?> </p>
            <p class="mb-2"><span class="font-semibold">Fecha:</span> <?php echo e(\App\Helpers\Helpers::formatFecha($ordenSeleccionada->created_at)); ?>

                <span class="font-semibold">Hora:</span> <?php echo e(\App\Helpers\Helpers::formatHora($ordenSeleccionada->created_at)); ?>

            </p>
       

        </div>

        <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
            <h2 class="font-bold text-xl mb-2">Acciones:</h2>
            <a href="<?php echo e(route('generate-labels', $ordenSeleccionada->id)); ?>" class="text-blue-500 hover:underline">Generar etiquetas</a>
        

            <!--[if BLOCK]><![endif]--><?php if(auth()->user()->hasRole('Quimico')): ?>
            <!--[if BLOCK]><![endif]--><?php if(!$reportes_especiales->isEmpty()): ?>
            <ul>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $reportes_especiales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li wire:click="capturarResultadosRE(<?php echo e($item->id); ?>)" class="text-blue-500 hover:underline">
                        Capturar resultados de <?php echo e($item->nombre); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </ul>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            <ul>
                <li wire:click="capturarResultados(<?php echo e($ordenSeleccionada->id); ?>)" class="text-blue-500 hover:underline">
                    <?php echo e(($ordenSeleccionada->estado === 'espera' ? 'Capturar': 'Modificar')); ?> resultados
                </li>
           
                <!--[if BLOCK]><![endif]--><?php if($ordenSeleccionada->estado === 'resultados'): ?>
                <li wire:click="validarResultados(<?php echo e($ordenSeleccionada->id); ?>)" class="text-blue-500 hover:underline">Validar resultados</li>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

                <!--[if BLOCK]><![endif]--><?php if($ordenSeleccionada->estado === 'validados'): ?>
                <a href="<?php echo e(route('generate-informe', $ordenSeleccionada->id)); ?>" class="text-blue-500 hover:underline">Generar informe de resultados</a>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </ul>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->     
                 
        </div>
    </div>

    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\Sistema_QuechuLAB\resources\views/livewire/detalle-orden.blade.php ENDPATH**/ ?>