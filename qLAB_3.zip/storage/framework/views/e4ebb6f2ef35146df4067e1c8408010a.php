<div>
    
    <label>Doctor:</label>
    <input type="text" wire:model.live="doctor" placeholder="A quien corresponda" class="form-control rounded-md shadow-sm border-gray-300">
    
</div>
<?php /**PATH C:\xampp\htdocs\Sistema_QuechuLAB\resources\views/livewire/doctor.blade.php ENDPATH**/ ?>