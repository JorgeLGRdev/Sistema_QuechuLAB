<div class="container mx-auto px-4">

    <div class="overflow-y-auto">
        <div class="grid grid-cols-2 gap-4">
            <div>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('detalleEstudio');

$__html = app('livewire')->mount($__name, $__params, 'AGZYNg1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        
            <div>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('formulario-v-r');

$__html = app('livewire')->mount($__name, $__params, '4AXJF71', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
            
        <div>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tabla-v-r');

$__html = app('livewire')->mount($__name, $__params, 'D0QjX9s', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
        <br>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\Sistema_QuechuLAB\resources\views/livewire/crud-valores-referencia.blade.php ENDPATH**/ ?>