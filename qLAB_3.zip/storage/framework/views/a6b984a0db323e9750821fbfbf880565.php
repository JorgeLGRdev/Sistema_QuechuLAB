<!DOCTYPE html>
<html>
<head>
    <title>Etiqueta</title>
    <style>
        /* Asegúrate de que los estilos se ajusten a las especificaciones de tu impresora de etiquetas */
        body {
            font-family: 'Arial', sans-serif;
            width: 4in; /* Ajusta el ancho al tamaño de tus etiquetas */
            height: 6in; /* Ajusta la altura al tamaño de tus etiquetas */
        }
        .etiqueta {
            border: 1px solid #000;
            padding: 10px;
            margin: 10px;
        }
    </style>
</head>
<body>
    <?php $__currentLoopData = $muestras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $muestra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="etiqueta">
            <h2>Paciente: <?php echo e($paciente); ?></h2>
            <p>tipo de muestra: <?php echo e($muestra); ?></p>
            <p>estudios:<?php echo e($estudiosMuestra = $estudios[array_search($muestra, $muestras)]); ?></p>
            <p>orden: <?php echo e($detalleOrden_id); ?> <?php echo $codigoDeBarras; ?></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Sistema_QuechuLAB\resources\views/ordenes/etiqueta.blade.php ENDPATH**/ ?>