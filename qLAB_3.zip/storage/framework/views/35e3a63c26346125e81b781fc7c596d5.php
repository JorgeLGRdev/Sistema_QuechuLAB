<div>
    
    <input type="text" wire:model.live="search" placeholder="Buscar estudio..." class="form-control rounded-md shadow-sm border-gray-300" autofocus>
    <hr>
    <div wire:loading>Buscando...</div>
    <!--[if BLOCK]><![endif]--><?php if($studies): ?>
        <ul>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $studies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $study): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li wire:click="selectStudy(<?php echo e($study->id); ?>)" class="hover:bg-teal-200 text-blue" ><?php echo e($study->id); ?> - <?php echo e($study->nombre); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
        </ul>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\Sistema_QuechuLAB\resources\views/livewire/buscador-estudios.blade.php ENDPATH**/ ?>