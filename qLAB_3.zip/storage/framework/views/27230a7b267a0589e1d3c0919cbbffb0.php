<div>
    
    <input type="text" wire:model.live="busquedaOrden" placeholder="Buscar orden por clave..." class="form-control rounded-md shadow-sm border-gray-300" autofocus>
    <hr>
    <div wire:loading>Buscando...</div>
</div>
<?php /**PATH C:\xampp\htdocs\Sistema_QuechuLAB\resources\views/livewire/buscador-ordenes.blade.php ENDPATH**/ ?>