<div>
    
    <div>
        Fecha: <?php echo e($date); ?>

        Hora: <span wire:poll.1000ms="refreshTime"><?php echo e($time); ?></span>    
    </div>
        <h3 class="text-lg leading-6 font-medium text-gray-900">
            Lista ordenes de análisis creadas este dia
        </h3>
        <table class="w-full text-sm text-left text-gray-500">
            <thead class="text-xs text-gray-900 uppercase bg-teal-500">
                <tr class="hover:bg-teal-700 text-white">
                    <th scope="col" class="px-6 py-3">Clave</th>
                    <th scope="col" class="px-6 py-3">Paciente</th>
                    <th scope="col" class="px-6 py-3">Estado</th>
                    <th scope="col" class="px-6 py-3">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php if($ordenesDelDia): ?>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $ordenesDelDia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="bg-white hover:bg-teal-100 text-blue">
                        <td class="px-6 py-4">
                            <?php echo e($orden->id); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e(\App\Helpers\Helpers::nombrePaciente($orden->paciente_id)); ?>

                        </td>
                        <td class="px-6 py-4">
                            <?php echo e($orden->estado === 'espera' ? 'EN ESPERA':''); ?>

                            <?php echo e($orden->estado === 'resultados' ? 'RESULTADOS CAPTURADOS':''); ?>

                            <?php echo e($orden->estado === 'validados' ? 'RESULTADOS VALIDADOS':''); ?>

                        </td>
                        <td class="px-6 py-4">
                            <ul>
                                <li class="text-blue-500 hover:text-blue-700">
                                    <a href="<?php echo e(route('generate-labels', $orden->id)); ?>">Generar Etiquetas</a>
                                </li>
                                <!--[if BLOCK]><![endif]--><?php if(auth()->user()->hasRole('Quimico')): ?>
                                    <!--[if BLOCK]><![endif]--><?php if($orden->estado === 'validados'): ?>
                                    <li class="text-blue-500 hover:text-blue-700">
                                        <a href="<?php echo e(route('generate-informe', $orden->id)); ?>">Generar Informe de Resultados</a>
                                    </li>
                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                            </ul>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
      
</div>
<?php /**PATH C:\xampp\htdocs\Sistema_QuechuLAB\resources\views/livewire/dashboard.blade.php ENDPATH**/ ?>