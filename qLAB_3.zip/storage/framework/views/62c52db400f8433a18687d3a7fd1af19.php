<div>
    <input type="text" wire:model.live="busqueda" placeholder="Buscar paciente..." class="form-control rounded-md shadow-sm border-gray-300">
    <hr>
    <ul>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li wire:click="seleccionarPaciente(<?php echo e($paciente->id); ?>)" class="hover:bg-teal-200 text-blue">
                <?php echo e($paciente->nombre); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
    </ul>

    <!--[if BLOCK]><![endif]--><?php if($pacienteSeleccionado): ?>
    <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        <h2 class="font-bold text-xl mb-2">Datos del Paciente:</h2>
        <p class="mb-2"><span class="font-semibold">Nombre:</span> <?php echo e($pacienteSeleccionado->nombre); ?> <?php echo e($pacienteSeleccionado->apellido_paterno); ?> <?php echo e($pacienteSeleccionado->apellido_materno); ?></p>
        <p class="mb-2"><span class="font-semibold">Sexo:</span> <?php echo e(($pacienteSeleccionado->sexo == 'M') ? 'Masculino':'Femenino'); ?></p>
        <p class="mb-2"><span class="font-semibold">Edad:</span> <?php echo e(\App\Helpers\Helpers::obtenerEdad($pacienteSeleccionado->fecha_nacimiento)); ?></p>
    </div>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\Sistema_QuechuLAB\resources\views/livewire/pacientes.blade.php ENDPATH**/ ?>