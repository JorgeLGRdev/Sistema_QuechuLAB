<div class="bg-white shadow overflow-hidden sm:rounded-lg p-6">
    <!--[if BLOCK]><![endif]--><?php if($estudio): ?>
    <h2 class="text-2xl font-bold text-gray-900 mb-2">Nombre: <span class="font-normal"><?php echo e($estudio->nombre); ?></span></h2>
    <p class="text-lg text-gray-700 mb-1">Contenedor: <span class="font-medium"><?php echo e($estudio->contenedor); ?></span></p>
    <p class="text-lg text-gray-700 mb-1">Método: <span class="font-medium"><?php echo e($estudio->metodo); ?></span></p>
    <p class="text-lg text-gray-700 mb-1">Abreviatura: <span class="font-medium"><?php echo e($estudio->abreviatura); ?></span></p>
    <p class="text-lg text-gray-700 mb-1">Unidades: <span class="font-medium"><?php echo e($estudio->unidades); ?></span></p>
    <p class="text-lg text-gray-700 mb-1">Tipo de muestra: <span class="font-medium"><?php echo e($estudio->tipo_muestra); ?></span></p>
    <p class="text-lg text-gray-700 mb-1">Sexo: <span class="font-medium"><?php echo e(($estudio->sexo =='F'? 'Femenino' : ($estudio->sexo =='M' ? 'Masculino':'General') )); ?></span></p>
    <p class="text-lg text-gray-700 mb-1">Horas de proceso: <span class="font-medium"><?php echo e($estudio->horas_proceso); ?></span></p>
    <p class="text-lg text-gray-700 mb-1">Dias de entrega: <span class="font-medium"><?php echo e($estudio->dias_entrega); ?></span></p>
    <p class="text-lg text-gray-700 mb-1">Reporte especial: <span class="font-medium"><?php echo e(($estudio->reporte_especial='S'? 'Si':'No')); ?></span></p>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\Sistema_QuechuLAB\resources\views/livewire/mostrar-estudio.blade.php ENDPATH**/ ?>