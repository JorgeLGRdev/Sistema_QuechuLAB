<div>
    <div>
        Fecha: <?php echo e($date); ?>

        Hora: <span wire:poll.1000ms="refreshTime"><?php echo e($time); ?></span>    
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Sistema_QuechuLAB\resources\views/livewire/reloj.blade.php ENDPATH**/ ?>