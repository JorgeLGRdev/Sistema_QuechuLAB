<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Recibo de pago</title>
    <style>
        .content {
            margin: auto;
            width: 90%;
            padding: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .row {
            display: flex;
        }
        .column {
            flex: 50%;
            padding: 10px;
        }
    </style>
</head>
<body>

    <div class="content">
        <h1>Laboratorio de análisis clinicos QuechuLAB</h1>
        <p>Calle Allende #9 Col. Centro esquina con Benito Juárez. Tel. (747) 499-0495 </p>
        <hr>

        <div class="row">
            <div class="column">
                <p>Clave: <?php echo e($detalleOrden->id); ?>  <?php echo $codigoDeBarras; ?></p>
               
            </div>
            <div class="column">
                <p>Paciente: <?php echo e($paciente->nombre); ?> <?php echo e($paciente->apellido_paterno); ?> <?php echo e($paciente->apellido_materno); ?> </p>
                <p>Sexo: <?php echo e($paciente->sexo == "F" ? 'Femenino' : 'Masculino'); ?>   Edad: <?php echo e(\App\Helpers\Helpers::obtenerEdad($paciente->fecha_nacimiento)); ?> </p>
                <p>Dr(a): <?php echo e($detalleOrden->doctor); ?></p>
                <p>Fecha de entrega: <?php echo e(\App\Helpers\Helpers::formatFecha(now()->format('d-m-Y'))); ?>   Hora de entrega: <?php echo e(now()->format('H:i:s')); ?>

                </p>
            </div>
        </div>
        <hr>
        <div>
            <table>
                <thead>
                    <tr>
                        <th>Estudios</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $estudios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($estudio->nombre); ?></td>
                            <td><?php echo e($estudio->precio); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <p>Total: <?php echo e($detalleOrden->total); ?></p>
                </tbody>
            </table>
        </div>
        <div>
            <p>Nota: Autorizo a Laboratorio de análisis clinicos QuechuLAB realice los estudios solicitados, conociendo los requisitos para la realización y riesgos del procedimiento de toma de muestra: Hematoma, Desmayo, Repeticion de la toma, Solicitud de nueva muestra.
                Acepto la responsabilidad de otorgar la concesión para realizar estudios en caso de no cumplir con los requisitos.
                El Laboratorio clinico se compromete a la confidencialidad de la información solicitada, excepto en los casos indicados por las autoridades competentes.
            </p>
        </div>
    </div>
  
</body>

</html><?php /**PATH C:\xampp\htdocs\Sistema_QuechuLAB\resources\views/ordenes/recibo_de_pago.blade.php ENDPATH**/ ?>