<div>
    
</div>
<?php /**PATH C:\xampp\htdocs\Sistema_QuechuLAB\resources\views/livewire/buscador-perfiles.blade.php ENDPATH**/ ?>