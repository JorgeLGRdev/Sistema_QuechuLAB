<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Informe de resultados</title>
    <style>
           @page {
            margin: 0cm 0cm;
        }

        header {
            position: fixed;
            top: 0cm;
            left: 1cm;
            right: 1cm;
            height: 2cm;

            /** Aquí puedes estilizar tu membrete **/
        }

        body {
            font-family: 'Arial', sans-serif;
            margin: 4.5cm 1cm 1cm;
        }

          .content {
            margin: auto;
            width: 90%;
            padding: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 1px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
       
        .texto-negrita {
            font-weight: bold;
        }
        .texto-pequeno {
            font-size: small;
        }
        .texto-extra-pequeno {
            font-size: 12px;
        }
        .text-right{
            text-align: right;
        }
        .text-left{
            text-align: left;
        }
        .text-center{
            text-align: center;
        }

        footer {
            position: fixed;
            bottom: 0cm;
            left: 1cm;
            right: 1cm;
            height: 2cm;
        }
    </style>
</head>
<body>
  <header>
    <div>
        <table>
            <tbody class="texto-pequeno">
                <tr>
                    <td><img src="<?php echo e(public_path('images/quechulab-logo.jpeg')); ?>" alt="Icono" width="130" height="100">
                    </td>
                    <td class="text-left">
                        <p class="texto-negrita">Quechultenango, Gro</p>
                        
                        <p class="texto-extra-pequeno">Calle Allende #9, Col. Centro,</p>
                        <p class="texto-extra-pequeno">esquina con Benito Juárez a un costado</p>
                        <p class="texto-extra-pequeno">de la Iglesia Santiago Apostol C.P. 39250</p>
                    </td>
                    <td class="text-right">
                        <p class="texto-negrita">747 499 0495</p>
                        <p class="texto-negrita">Q.B.P. Jesús Isaí</p>
                        <p class="texto-extra-pequeno">Dozal Barrios</p>
                        <p class="texto-extra-pequeno">CED. PROF. 11888986</p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
  </header>
    <div>
        <table>
            <tbody class="texto-pequeno">
                <tr>
                    <td colspan="3" class="texto-negrita"> 
                        Paciente: <?php echo e($paciente->apellido_paterno); ?> <?php echo e($paciente->apellido_materno); ?> <?php echo e($paciente->nombre); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        Edad: <?php echo e(\App\Helpers\Helpers::obtenerEdad($paciente->fecha_nacimiento)); ?>

                    </td>
                    <td>
                        Sexo: <?php echo e($paciente->sexo === 'F' ? 'Femenino': 'Masculino'); ?>

                    </td>
                    <td></td>
                    <td class="texto-negrita"><?php echo e($detalleOrden->id); ?></td>
                </tr>
                <tr>
                    <td colspan="2">PARTICULAR</td>
                    <td>Fecha: <?php echo e(\App\Helpers\Helpers::formatFecha($detalleOrden->created_at)); ?></td>
                    <td><?php echo $codigoDeBarras; ?></td>
                </tr>
                <tr>
                    <td colspan="2">
                        Impresión: <?php echo e(\App\Helpers\Helpers::obtenerDia()); ?>, <?php echo e(\App\Helpers\Helpers::formatFecha(now()->format('d-m-Y'))); ?>, <?php echo e(date('H:i')); ?>

                    </td>
                    <td>
                        Hora: <?php echo e(\App\Helpers\Helpers::formatHora($detalleOrden->created_at)); ?>

                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        Dr(a). : <?php echo e($detalleOrden->doctor); ?>

                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <hr>
    <table>
        <thead>
            <tr class="texto-pequeno">
                <th>ESTUDIO</th>
                <th>RESULTADO</th>
                <th>UNIDADES</th>
                <th colspan="3">VALORES DE REFERENCIA</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $estudios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $estudio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <?php if($estudio->es_perfil ==='s'): ?>
                    <tr class="texto-pequeno">
                            <td class="texto-negrita">
                                <p>
                                    <?php echo e($estudio->nombre); ?> 
                                </p>
                                <p class="texto-extra-pequeno">
                                    Método: <?php echo e($estudio->metodo); ?>

                                </p>
                            </td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <?php else: ?> 
                        <?php if($estudio->reporte_especial === 'S'): ?>
                        <tr class="texto-pequeno"> 
                            <td><p><?php echo e($estudio->nombre); ?></p></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                           
                            <?php
                                $resultadosAux = \App\Helpers\Helpers::obtenerResultados($estudio->id, $detalleOrden->id);               
                            ?>
                            <?php if(!$resultadosAux->isEmpty()): ?>
                                <?php $__currentLoopData = $resultadosAux; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="texto-pequeno">
                                        <td><?php echo e($resultado->parametro); ?></td>
                                        <td class="text-center">
                                            <?php if($resultado->val_ref_texto != '' || $resultado->val_ref_inicial != '' || $resultado->val_ref_final != ''): ?>
                                                <?php echo e($resultado->resultado); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($resultado->unidades); ?></td>

                                        <td><?php echo e($resultado->val_ref_texto); ?></td>
                                        <td><?php echo e($resultado->val_ref_inicial); ?></td>
                                        <td><?php echo e($resultado->val_ref_final); ?></td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                            <?php endif; ?>
                        <?php else: ?>
                        <tr class="texto-pequeno">
                            <td><p><?php echo e($estudio->nombre); ?></p></td>
                            <td class="text-center">
                                <?php
                                $resultado = $resultados->get($index);
                                ?>
                            <?php echo e(($resultado) ? $resultado->resultado:''); ?></p>
                            </td>
                            <td class="text-left"><?php echo e($estudio->unidades); ?></td>
                            <td colspan="3">
                                <?php
                                    $vReferencias = $valoresReferencias->get($index);
                                ?>
                                <?php if($vReferencias): ?>
                                <table>
                                    <tbody>
                                        <?php $__currentLoopData = $vReferencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valorReferencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($valorReferencia->valor_texto); ?></td>
                                            <td><?php echo e($valorReferencia->valor_inicial); ?></td>
                                            <td><?php echo e($valorReferencia->valor_final); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <?php endif; ?>
                            </td>
                        </tr>
                       
                        <?php endif; ?>
                        
                    <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <hr>
    <br>
    <table>
        <tbody class="texto-pequeno">
            <tr>
                <td rowspan="2">
                    Revisó resultados: Q.B.P. JESÚS ISAÍ DOZAL BARRIOS</td>
                <td>
                    <br><br>
                    <p>RESPONSABLE SANITARIO</p>
                    <p>Q.B.P. JESÚS ISAÍ DOZAL BARRIOS <br>CED. PROF. 11888986</p>
                </td>
            </tr>
          
        </tbody>
    </table>
    <footer>
        <div class="page-number">
            <span class="pagenum"></span>
        </div>
    </footer>

    <script type="text/php">
        if (isset($pdf)) {
            $x = 500;
             $y = 800;
             $text = "Página: {PAGE_NUM} de {PAGE_COUNT}";
             $font = $fontMetrics->getFont("Arial", "bold");
            $size = 10;
            $color = array(0,0,0);
            $word_space = 0.0;  //  default
            $char_space = 0.0;  //  default
            $angle = 0.0;   //  default
            $pdf->page_text($x, $y, $text, $font, $size, $color, $word_space, $char_space, $angle);
        }
    </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\Sistema_QuechuLAB\resources\views/ordenes/informe.blade.php ENDPATH**/ ?>