const mix = require('laravel-mix');

mix.js('resources/js/mi-script.js', 'public/js');
