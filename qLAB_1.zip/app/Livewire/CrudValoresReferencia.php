<?php

namespace App\Livewire;

use App\Models\Estudio;
use Livewire\Component;

class CrudValoresReferencia extends Component
{
    public function render()
    {
        return view('livewire.crud-valores-referencia');
    }
}
